# Space Game
## A GBA Masterpiece

### Story
Aliens are invading, and it is your job to stop them before they can reach and destroy earth. 

### Game
Move the character with the D-Pad, and fire lasers with A. Get a score of 10 to win. Beware--if your health decreases too much, you lose and the aliens win!
