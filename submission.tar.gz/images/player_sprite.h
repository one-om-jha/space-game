/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 player_sprite player_sprite.png 
 * Time-stamp: Sunday 11/07/2021, 00:20:58
 * 
 * Image Information
 * -----------------
 * player_sprite.png 15@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_SPRITE_H
#define PLAYER_SPRITE_H

extern const unsigned short player_sprite[240];
#define PLAYER_SPRITE_SIZE 480
#define PLAYER_SPRITE_LENGTH 240
#define PLAYER_SPRITE_WIDTH 15
#define PLAYER_SPRITE_HEIGHT 16

#endif

