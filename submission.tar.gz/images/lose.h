/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 lose lose.jpg 
 * Time-stamp: Sunday 11/07/2021, 04:06:15
 * 
 * Image Information
 * -----------------
 * lose.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSE_H
#define LOSE_H

extern const unsigned short lose[38400];
#define LOSE_SIZE 76800
#define LOSE_LENGTH 38400
#define LOSE_WIDTH 240
#define LOSE_HEIGHT 160

#endif

