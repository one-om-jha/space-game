/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 enemy_sprite enemy_sprite.png 
 * Time-stamp: Sunday 11/07/2021, 01:09:22
 * 
 * Image Information
 * -----------------
 * enemy_sprite.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMY_SPRITE_H
#define ENEMY_SPRITE_H

extern const unsigned short enemy_sprite[225];
#define ENEMY_SPRITE_SIZE 450
#define ENEMY_SPRITE_LENGTH 225
#define ENEMY_SPRITE_WIDTH 15
#define ENEMY_SPRITE_HEIGHT 15

#endif

