/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 player_sprite_right player_sprite_right.png 
 * Time-stamp: Sunday 11/07/2021, 03:36:32
 * 
 * Image Information
 * -----------------
 * player_sprite_right.png 15@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_SPRITE_RIGHT_H
#define PLAYER_SPRITE_RIGHT_H

extern const unsigned short player_sprite_right[240];
#define PLAYER_SPRITE_RIGHT_SIZE 480
#define PLAYER_SPRITE_RIGHT_LENGTH 240
#define PLAYER_SPRITE_RIGHT_WIDTH 15
#define PLAYER_SPRITE_RIGHT_HEIGHT 16

#endif

