/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 player_sprite_left player_sprite_left.png 
 * Time-stamp: Sunday 11/07/2021, 03:34:43
 * 
 * Image Information
 * -----------------
 * player_sprite_left.png 15@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_SPRITE_LEFT_H
#define PLAYER_SPRITE_LEFT_H

extern const unsigned short player_sprite_left[240];
#define PLAYER_SPRITE_LEFT_SIZE 480
#define PLAYER_SPRITE_LEFT_LENGTH 240
#define PLAYER_SPRITE_LEFT_WIDTH 15
#define PLAYER_SPRITE_LEFT_HEIGHT 16

#endif

